(function(){"use strict";function E(e){return e}function s(){var m,f,b,x,g,y,p;const e=document.querySelector("h1.ytd-watch-metadata"),t=((m=e==null?void 0:e.innerText)==null?void 0:m.trim())||null,o=document.title||null,r=document.querySelector("#channel-name a"),n=((f=r==null?void 0:r.innerText)==null?void 0:f.trim())||null;let c=null;const d=document.querySelector("#description-inline-expander");if(d&&(c=((b=d.innerText)==null?void 0:b.trim())||null),!c){const h=document.querySelector("#description, ytd-expander #description");h&&(c=((x=h.innerText)==null?void 0:x.trim())||null)}const S=(g=document.querySelector('meta[name="keywords"]'))==null?void 0:g.getAttribute("content"),v=(y=document.querySelector('meta[property="og:title"]'))==null?void 0:y.getAttribute("content"),B=(p=document.querySelector('meta[property="og:description"]'))==null?void 0:p.getAttribute("content"),C=[t,o,n,c,S,v,B].filter(Boolean).join(" ").trim();return{videoTitle:t,description:c,channelName:n,documentTitle:o,rawTextBlob:C}}function a(){if(document.getElementById("scoutfox-amazon-button"))return;const e=document.querySelector("#top-level-buttons-computed, ytd-menu-renderer, #actions, .ytd-watch-flexy");if(!e){const t=document.querySelector("ytd-watch-metadata, #above-the-fold");t&&u(t);return}u(e)}function u(e){const t=document.createElement("button");if(t.id="scoutfox-amazon-button",t.textContent="Search for Products",t.className="scoutfox-amazon-btn",t.addEventListener("click",async()=>{t.disabled=!0,t.textContent="Searching...";try{const o=s(),r=await chrome.runtime.sendMessage({type:"SEARCH_AMAZON_FROM_YOUTUBE",context:o});r.success&&r.url?window.open(r.url,"_blank"):alert("Failed to extract product. Please try again.")}catch(o){console.error("ScoutFox: Error searching Amazon",o),alert("An error occurred. Please try again.")}finally{t.disabled=!1,t.textContent="Search for Products"}}),!document.getElementById("scoutfox-amazon-button-styles")){const o=document.createElement("style");o.id="scoutfox-amazon-button-styles",o.textContent=`
      .scoutfox-amazon-btn {
        background: linear-gradient(135deg, #FF6B35 0%, #FF8C5A 100%);
        color: white;
        border: none;
        border-radius: 18px;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        margin-left: 8px;
        transition: all 0.2s;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      .scoutfox-amazon-btn:hover {
        background: linear-gradient(135deg, #E55A2B 0%, #FF6B35 100%);
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(255, 107, 53, 0.3);
      }
      .scoutfox-amazon-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
    `,document.head.appendChild(o)}e.appendChild(t)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{setTimeout(a,1e3)}):setTimeout(a,1e3);let l=location.href;new MutationObserver(()=>{const e=location.href;if(e!==l){l=e;const t=document.getElementById("scoutfox-amazon-button");t&&t.remove(),setTimeout(a,1e3)}}).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("popstate",()=>{const e=document.getElementById("scoutfox-amazon-button");e&&e.remove(),setTimeout(a,1e3)}),chrome.runtime.onMessage.addListener((e,t,o)=>{var r;if(e.action==="extractYouTubeContext"){try{console.log("[YouTube] Extracting context...");const n=s();if(console.log("[YouTube] Context extracted:",{hasVideoTitle:!!n.videoTitle,hasDescription:!!n.description,hasChannelName:!!n.channelName,rawTextBlobLength:((r=n.rawTextBlob)==null?void 0:r.length)||0}),!n.videoTitle&&!n.documentTitle)return console.warn("[YouTube] No title found in context"),o({success:!1,error:"Could not find video title on page. Make sure you are on a YouTube video page."}),!0;o({success:!0,data:n})}catch(n){console.error("[YouTube] Error extracting context:",n),o({success:!1,error:String(n)})}return!0}return!1});const T={matches:["*://www.youtube.com/watch*"],main(){}};function i(e,...t){}var w={debug:(...e)=>i(console.debug,...e),log:(...e)=>i(console.log,...e),warn:(...e)=>i(console.warn,...e),error:(...e)=>i(console.error,...e)};(async()=>{try{await T.main()}catch(e){w.error('The unlisted script "youtube" crashed on startup!',e)}})()})();
