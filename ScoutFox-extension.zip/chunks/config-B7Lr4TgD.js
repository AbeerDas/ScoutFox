const p="https://yt-amazon-backend-proxy.vercel.app";export{p as VERCEL_API_URL};
